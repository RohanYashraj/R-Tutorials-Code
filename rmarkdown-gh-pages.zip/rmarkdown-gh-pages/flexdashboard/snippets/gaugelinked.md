### Linked Gauge

```{r}
gauge(42, min = 0, max = 50, href="#details")
```
