```{r}
shinyAppDir(
  system.file("examples/06_tabsets", package="shiny"),
  options = list(height=850)
)
```