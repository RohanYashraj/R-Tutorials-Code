### Cars

```{r}
DT::datatable(mtcars, options = list(
  pageLength = 25
))
```
