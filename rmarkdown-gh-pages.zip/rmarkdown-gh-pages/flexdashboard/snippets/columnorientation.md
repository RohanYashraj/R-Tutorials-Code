---
title: "Column Orientation"
output: flexdashboard::flex_dashboard
---
    
Column
-------------------------------------
    
### Chart 1
    
```{r}
```
   
Column
-------------------------------------
   
### Chart 2

```{r}
```   
 
### Chart 3
    
```{r}
```
