---
title: "Row Orientation"
output: 
  flexdashboard::flex_dashboard:
    orientation: rows
---
    
Row
-------------------------------------
    
### Chart 1
    
```{r}
```
 
### Chart 2
    
```{r}
``` 

Row
-------------------------------------
    
### Chart 3
    
```{r}
```
    
### Chart 4

```{r}
```
