---
title: "Custom Chart Height"
output: flexdashboard::flex_dashboard
---
    
### Chart 1 {data-height=600}
    
```{r}
```

### Chart 2 {data-height=200}

```{r}
```

### Chart 3 {data-height=200}

```{r}
```



