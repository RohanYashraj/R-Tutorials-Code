### All Lung Deaths {.no-title}

```{r}
dygraph(ldeaths)
```
