---
title: "Default Figure Sizes"
output: 
  flexdashboard::flex_dashboard:
    fig_width: 8
    fig_height: 6
---
