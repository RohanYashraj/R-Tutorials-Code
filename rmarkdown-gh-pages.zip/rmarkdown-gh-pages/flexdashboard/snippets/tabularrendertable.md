### Cars

```{r}
renderTable({
  head(mtcars, n = input$rows)
})
```
