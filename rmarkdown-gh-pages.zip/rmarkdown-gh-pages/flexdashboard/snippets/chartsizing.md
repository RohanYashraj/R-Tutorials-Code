---
title: "Chart Sizing"
output: 
  flexdashboard::flex_dashboard:
    orientation: rows
---

Row {data-height=650}
-------------------------------------

### Chart 1

```{r}
```

Row {data-height=350}
-------------------------------------
    
### Chart 2
    
```{r}
```
    
### Chart 3

```{r}
```
