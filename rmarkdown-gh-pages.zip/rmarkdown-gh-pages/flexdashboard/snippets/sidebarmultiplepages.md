---
title: "Sidebar for Multiple Pages"
output: flexdashboard::flex_dashboard
runtime: shiny
---

Sidebar {.sidebar}
=====================================

```{r}
# shiny inputs defined here
```

Page 1
=====================================  

### Chart 1
    
```{r}
```
   
Page 2
=====================================     

### Chart 2
    
```{r}
```
