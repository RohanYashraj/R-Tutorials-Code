### Chart 1 {.no-padding}
    
```{r}
```
    
### Chart 2 {data-padding=10}

```{r}
```