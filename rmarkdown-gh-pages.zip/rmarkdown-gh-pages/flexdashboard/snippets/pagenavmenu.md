---
title: "Page Navigation Menus"
output: flexdashboard::flex_dashboard
---

Page 1 {data-navmenu="Menu A"}
=====================================


Page 2 {data-navmenu="Menu A"}
=====================================  


Page 3 {data-navmenu="Menu B"}
=====================================


Page 4 {data-navmenu="Menu B"}
=====================================  
