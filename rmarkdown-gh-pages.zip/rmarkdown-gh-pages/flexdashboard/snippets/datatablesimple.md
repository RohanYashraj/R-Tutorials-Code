### Cars

```{r}
DT::datatable(mtcars, options = list(
  bPaginate = FALSE
))
```
