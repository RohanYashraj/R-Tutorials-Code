---
title: "Focal Chart (Left)"
output: flexdashboard::flex_dashboard
---
    
Column {data-width=600}
-------------------------------------
    
### Chart 1
    
```{r}
```
   
Column {data-width=400}
-------------------------------------
   
### Chart 2

```{r}
```   
 
### Chart 3
    
```{r}
```
