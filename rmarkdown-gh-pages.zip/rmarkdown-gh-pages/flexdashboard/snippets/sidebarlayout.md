---
title: "Sidebar"
output: flexdashboard::flex_dashboard
runtime: shiny
---

Inputs {.sidebar}
-------------------------------------

```{r}
# shiny inputs defined here
```
 
Column
-------------------------------------
    
### Chart 1
    
```{r}
```
    
### Chart 2

```{r}
```
