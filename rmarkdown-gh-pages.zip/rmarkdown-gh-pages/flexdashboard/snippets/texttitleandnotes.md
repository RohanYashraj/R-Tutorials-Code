### All Lung Deaths

```{r}
dygraph(ldeaths)
```

> Monthly deaths from lung disease in the UK, 1974–1979
