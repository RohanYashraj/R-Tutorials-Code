### Linked Value Box

```{r}
valueBox(42, icon = "fa-pencil", href="#details")
```
