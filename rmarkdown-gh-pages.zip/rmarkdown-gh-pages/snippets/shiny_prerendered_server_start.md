```{r, context="server-start"}
library(DBI)
db <- dbConnect(...)
```