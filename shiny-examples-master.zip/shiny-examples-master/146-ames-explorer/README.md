This is the Ames Housing Explorer Shiny application discussed in the 2019 `rstudio::conf` presentation entitled __Effective use of Shiny modules__ created by [Eric Nantz](https://github.com/rpodcast).  You can view the application at [gallery.shinyapps.io/ames-explorer](https://gallery.shinyapps.io/ames-explorer/) This application requires the following packages (each available on CRAN):
* shiny
* dplyr
* ggplot2
* scales
* gghighlight
* DT
* AmesHousing
