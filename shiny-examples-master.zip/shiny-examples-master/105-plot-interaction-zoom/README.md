The plot on the left can be zoomed in by drawing a brush and then double-clicking on the brush.

The middle and right plots are linked: when you draw a brush on the middle plot, the right plot will automatically zoom to the brush's dimensions.
