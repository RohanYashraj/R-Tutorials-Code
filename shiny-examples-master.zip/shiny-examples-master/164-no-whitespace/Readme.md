This small Shiny application demonstrates how to suppress whitespace between HTML tags.

The .noWS argument can be specified when specifying a tag to suppress whitespace in or around it.

Note this feature requires **htmltools** >= 0.3.6.9004.
